package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player10;

public interface Player10Repository extends CrudRepository<Player10, Long> {
	List<Player10> findAll();
	
	@Query(value="SELECT * FROM P10 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player10> findByEventId(Long eventId);
	
	
}
