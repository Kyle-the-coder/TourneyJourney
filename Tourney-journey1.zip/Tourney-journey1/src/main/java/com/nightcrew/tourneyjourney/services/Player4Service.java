package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player4;
import com.nightcrew.tourneyjourney.repositories.Player4Repository;

@Service
public class Player4Service {
	@Autowired
	private Player4Repository p4Repo;
	
	public Player4Service(Player4Repository p4Repo) {
		this.p4Repo = p4Repo;
	}
	
	public List<Player4> allPlayer4(){
		return p4Repo.findAll();
	}
	
	public Player4 createPlayer4(Player4 p) {
		return p4Repo.save(p);
	}
	
	public List<Player4> findP4ByEventId(Long eventId){
		return p4Repo.findByEventId(eventId);
	}
}
