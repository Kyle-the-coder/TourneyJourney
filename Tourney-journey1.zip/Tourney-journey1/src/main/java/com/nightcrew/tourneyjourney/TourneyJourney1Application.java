package com.nightcrew.tourneyjourney;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourneyJourney1Application {

	public static void main(String[] args) {
		SpringApplication.run(TourneyJourney1Application.class, args);
	}

}
