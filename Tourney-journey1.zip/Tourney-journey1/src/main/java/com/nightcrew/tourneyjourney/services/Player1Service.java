package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player1;
import com.nightcrew.tourneyjourney.repositories.Player1Repository;

@Service
public class Player1Service {
	@Autowired
	private Player1Repository p1Repo;
	
	public Player1Service(Player1Repository p1Repo) {
		this.p1Repo = p1Repo;
	}
	
	public List<Player1> allPlayer1(){
		return p1Repo.findAll();
	}
	
	public Player1 createPlayer1(Player1 p) {
		return p1Repo.save(p);
	}
	
	public List<Player1> findP1ByEventId(Long eventId){
		return p1Repo.findByEventId(eventId);
	}
}
