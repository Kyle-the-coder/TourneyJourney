package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player16;
import com.nightcrew.tourneyjourney.repositories.Player16Repository;

@Service
public class Player16Service {

	@Autowired
	private Player16Repository p16Repo;
	
	public Player16Service(Player16Repository p16Repo) {
		this.p16Repo = p16Repo;
	}
	
	public List<Player16> allPlayer16(){
		return p16Repo.findAll();
	}
	
	public Player16 createPlayer16(Player16 p) {
		return p16Repo.save(p);
	}
	
	public List<Player16> findP16ByEventId(Long eventId){
		return p16Repo.findByEventId(eventId);
		
	}
	
}
