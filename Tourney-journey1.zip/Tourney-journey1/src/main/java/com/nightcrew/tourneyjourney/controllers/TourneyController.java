package com.nightcrew.tourneyjourney.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.nightcrew.tourneyjourney.models.Comment;
import com.nightcrew.tourneyjourney.models.Event;
import com.nightcrew.tourneyjourney.models.Participant;
import com.nightcrew.tourneyjourney.models.Player1;
import com.nightcrew.tourneyjourney.models.Player10;
import com.nightcrew.tourneyjourney.models.Player11;
import com.nightcrew.tourneyjourney.models.Player12;
import com.nightcrew.tourneyjourney.models.Player13;
import com.nightcrew.tourneyjourney.models.Player14;
import com.nightcrew.tourneyjourney.models.Player15;
import com.nightcrew.tourneyjourney.models.Player16;
import com.nightcrew.tourneyjourney.models.Player2;
import com.nightcrew.tourneyjourney.models.Player3;
import com.nightcrew.tourneyjourney.models.Player4;
import com.nightcrew.tourneyjourney.models.Player5;
import com.nightcrew.tourneyjourney.models.Player6;
import com.nightcrew.tourneyjourney.models.Player7;
import com.nightcrew.tourneyjourney.models.Player8;
import com.nightcrew.tourneyjourney.models.Player9;
import com.nightcrew.tourneyjourney.models.User;
import com.nightcrew.tourneyjourney.services.CommentService;
import com.nightcrew.tourneyjourney.services.EventService;
import com.nightcrew.tourneyjourney.services.ParticipantService;
import com.nightcrew.tourneyjourney.services.Player10Service;
import com.nightcrew.tourneyjourney.services.Player11Service;
import com.nightcrew.tourneyjourney.services.Player12Service;
import com.nightcrew.tourneyjourney.services.Player13Service;
import com.nightcrew.tourneyjourney.services.Player14Service;
import com.nightcrew.tourneyjourney.services.Player15Service;
import com.nightcrew.tourneyjourney.services.Player16Service;
import com.nightcrew.tourneyjourney.services.Player1Service;
import com.nightcrew.tourneyjourney.services.Player2Service;
import com.nightcrew.tourneyjourney.services.Player3Service;
import com.nightcrew.tourneyjourney.services.Player4Service;
import com.nightcrew.tourneyjourney.services.Player5Service;
import com.nightcrew.tourneyjourney.services.Player6Service;
import com.nightcrew.tourneyjourney.services.Player7Service;
import com.nightcrew.tourneyjourney.services.Player8Service;
import com.nightcrew.tourneyjourney.services.Player9Service;
import com.nightcrew.tourneyjourney.services.UserService;

@Controller
public class TourneyController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private EventService eventService;
	@Autowired
	private CommentService commentService;
	@Autowired
	private ParticipantService partService;
	@Autowired
	private Player1Service p1Service;
	@Autowired
	private Player2Service p2Service;
	@Autowired
	private Player3Service p3Service;
	@Autowired
	private Player4Service p4Service;
	@Autowired
	private Player5Service p5Service;
	@Autowired
	private Player6Service p6Service;
	@Autowired
	private Player7Service p7Service;
	@Autowired
	private Player8Service p8Service;
	@Autowired
	private Player9Service p9Service;
	@Autowired
	private Player10Service p10Service;
	@Autowired
	private Player11Service p11Service;
	@Autowired
	private Player12Service p12Service;
	@Autowired
	private Player13Service p13Service;
	@Autowired
	private Player14Service p14Service;
	@Autowired
	private Player15Service p15Service;
	@Autowired
	private Player16Service p16Service;
	
	
	//Dashboard
	
	@RequestMapping("/dashboard")
	public String dashboard(HttpSession session, Model model) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		
		//List for all Events
		List<Event> event = eventService.allEvents();
		model.addAttribute("eventList", event);
		
		//List for the Users Events
		Long userId = (Long) session.getAttribute("userId");
		User userEvent = userService.findUser(userId);
		model.addAttribute("userEventList", userEvent.getEvents());
		
		
	
		
		return "dashboard.jsp";
	}
	
	//Create New Event
	@GetMapping("/create/new/event")
	public String createEvent(@ModelAttribute("newEvent")Event event, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		return "createEvent.jsp";
	}
	
	//Add New Event
	@PostMapping("/create/new/event")
	public String addEvent(@Valid @ModelAttribute("newEvent")Event event, BindingResult result,
			HttpSession session, Model model) throws IOException {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		//process form
		if(result.hasErrors()) {
			
			return "createEvent.jsp";
			
		} else {
			
			//Create File for Photo
			MultipartFile multipartFile = event.getPhotoFile();
			String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			event.setPhotos(fileName);
			
			Event savedEvent = eventService.createEvent(event);
			
			
			String uploadDir = "./posted-img/" + savedEvent.getId();
			
			Path uploadPath = Paths.get(uploadDir);
			
			if(!Files.exists(uploadPath)) {
				Files.createDirectories(uploadPath);
			}
			
			try (InputStream inputStream = multipartFile.getInputStream()){
				Path filePath = uploadPath.resolve(fileName);
				System.out.println("hello");
				Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				throw new IOException("Could not save uploaded file: " + fileName);
			}
			
			return "redirect:/dashboard";
		}
			
	}
	
	
	//View One Event Details
	
	@GetMapping("/view/one/event/{id}")
	public String oneEvent(Model model, 
			@PathVariable("id")Long id, HttpSession session, 
			@ModelAttribute("newComment")Comment comments,
			@ModelAttribute("signUp") Participant signUp) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		//Details for the one Event
		Event event = eventService.findEvent(id);
		model.addAttribute("event", event);
		
		//Info for the likes button
		Long userId = (Long) session.getAttribute("userId");
		User loggedInUser = userService.findUser(userId);
		model.addAttribute("loggedInUser" , loggedInUser);
		
		//Methods for the comment section
		List<Comment> comment2 = commentService.findByEventId(id);
		model.addAttribute("commentList", comment2);
		List<Comment> eventComments = eventService.getUserComments(event);
		model.addAttribute("eventComments", eventComments);
	
		
		//List for Sign Up (Participants)
		model.addAttribute("partList", event.getEvent_participants());
		
		//Photo
		Event eventPhoto = (Event) eventService.findEvent(id);
		model.addAttribute("eventPhoto", eventPhoto);
		
		
		System.out.println(eventPhoto);
		return "showOne.jsp";
	}
 		
 		
 		
		
		
		
		
		
	
	

	//Edit Users Posted Event
	@RequestMapping("/edit/event/{id}")
	public String edit(@PathVariable("id")Long id,
			Model model, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		
		Event event2 = eventService.findEvent(id);
		model.addAttribute("editEvent", event2);
		return "editOne.jsp";
	}
	
	//Add Users Edited Event
	@PutMapping("/update/event/{id}")
	public String editEvent(@Valid @ModelAttribute("editEvent")Event event,
			BindingResult result, @PathVariable("id")Long id, Model model, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		if(result.hasErrors()) {
			return "editOne.jsp";
		} else {
			eventService.updateEvent(event);
			return "redirect:/view/one/event/{id}";
		}
	}
	
	
	//Delete Event
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable("id")Long id, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		eventService.deleteEvent(id);
		return "redirect:/dashboard";
	}
	
	//Likes
	@PutMapping("/likes/{id}")
	public String likes(@PathVariable("id")Long id, HttpSession session) {
		
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		
		Long userId = (Long) session.getAttribute("userId");
		User loggedInUser = userService.findUser(userId);
		Event event = eventService.findEvent(id);
		
		eventService.likeEvent(loggedInUser, event);
		return "redirect:/view/one/event/{id}";
	}
	
	//Unlike
	@PutMapping("/unLike/{id}")
	public String unLike(@PathVariable("id")Long id, HttpSession session) {
		
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		
		Long userId = (Long) session.getAttribute("userId");
		User loggedInUser = userService.findUser(userId);
		Event event = eventService.findEvent(id);
		
		eventService.unlikeEvent(loggedInUser, event);
		return "redirect:/view/one/event/{id}";
	}
	
	//Comment Save
	@PostMapping("/comment/{eventId}")
	public String comment(@PathVariable("eventId") Event id,
			HttpSession session,
			@Valid @ModelAttribute("newComment")Comment comment, BindingResult result) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		if(result.hasErrors()) {
			System.out.println(result);
			return "showOne.jsp";
		} else {
			
			//service method to save comment
			commentService.createComment(comment);
			return "redirect:/view/one/event/{eventId}";
		}
	}
	
	
	//Sign Up For Event(Participant)
	@PostMapping("/sign/up/{eventId}")
	public String signUp(@PathVariable("eventId")Event Id, HttpSession session,
			@Valid @ModelAttribute("signUp") Participant signUp, BindingResult result) {
	
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		if(result.hasErrors()) {
			return "showOne.jsp";
		} else {
			partService.createParticipant(signUp);
			return "redirect:/view/one/event/{eventId}";
		}
		
	}
	
	//Delete Sign Up (Participant)
	@PutMapping("/delete/part/{id}")
	public String unSignPart(@PathVariable("id")Long id, HttpSession session) {
		
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		
		Long userId = (Long) session.getAttribute("userId");
		User loggedInUser = userService.findUser(userId);
		Event event = eventService.findEvent(id);
		
		eventService.unPartEvent(loggedInUser, event);
		return "redirect:/view/one/event/{id}";
	}
	
	
	//Choose Event To Create Bracket
	@GetMapping("/gen/bracket")
	public String BracketEnt(HttpSession session, Model model) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		Long userId = (Long) session.getAttribute("userId");
		User userEvent = userService.findUser(userId);
		model.addAttribute("userEventList", userEvent.getEvents());
		return "bracketEntrance.jsp";
			
	}
	
	//Prelim Page 
	@GetMapping("/gen/one/bracket/{id}")
	public String GenBracket(HttpSession session, Model model, 
			@PathVariable("id")Long id, @ModelAttribute("newBrack")Player1 p1) {
		
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		
		//Details for the one Event
		Event event = eventService.findEvent(id);
		model.addAttribute("event", event);
		
		//List for Sign Up (Participants)
		model.addAttribute("partList", event.getEvent_participants());
		
		return "bracketGen.jsp";
	}
	
	//Tourney Journey Bracket Page
	@GetMapping("/bracket/{id}")
	public String bracket(HttpSession session,
			@PathVariable("id")Long id, Model model) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		//Event Info
		Event event = eventService.findEvent(id);
		model.addAttribute("event", event);
		
		//List for Sign Up (Participants)
		model.addAttribute("partList", event.getEvent_participants());
		
		//All Players (Participants)
		List<Player1> p1 = p1Service.findP1ByEventId(id);
		model.addAttribute("p1List", p1);
		
		List<Player2> p2 = p2Service.findP1ByEventId(id);
		model.addAttribute("p2List", p2);
		
		List<Player3> p3 = p3Service.findP3ByEventId(id);
		model.addAttribute("p3List", p3);
		
		List<Player4> p4 = p4Service.findP4ByEventId(id);
		model.addAttribute("p4List", p4);
		
		List<Player5> p5 = p5Service.findP5ByEventId(id);
		model.addAttribute("p5List", p5);
		
		List<Player6> p6 = p6Service.findP6ByEventId(id);
		model.addAttribute("p6List", p6);
		
		List<Player7> p7 = p7Service.findP7ByEventId(id);
		model.addAttribute("p7List", p7);
		
		List<Player8> p8 = p8Service.findP8ByEventId(id);
		model.addAttribute("p8List", p8);
		
		List<Player9> p9 = p9Service.findP9ByEventId(id);
		model.addAttribute("p9List", p9);
		
		List<Player10> p10 = p10Service.findP10ByEventId(id);
		model.addAttribute("p10List", p10);
		
		List<Player11> p11 = p11Service.findP11ByEventId(id);
		model.addAttribute("p11List", p11);
		
		List<Player12> p12 = p12Service.findP12ByEventId(id);
		model.addAttribute("p12List", p12);
		
		List<Player13> p13 = p13Service.findP13ByEventId(id);
		model.addAttribute("p13List", p13);
		
		List<Player14> p14 = p14Service.findP14ByEventId(id);
		model.addAttribute("p14List", p14);
		
		List<Player15> p15 = p15Service.findP15ByEventId(id);
		model.addAttribute("p15List", p15);
		
		List<Player16> p16 = p16Service.findP16ByEventId(id);
		model.addAttribute("p16List", p16);
		

		

		
		return "bracket.jsp";
	}
	
	
	//Creating the Players
	@PostMapping("/gen/brack/{id}")
	public String genBrack(HttpSession session,
			@PathVariable("id")Long id,
			Player1 p1, Player2 p2, Player3 p3, Player4 p4,
			Player5 p5, Player6 p6, Player7 p7, Player8 p8,
			Player9 p9, Player10 p10, Player11 p11, Player12 p12,
			Player13 p13, Player14 p14, Player15 p15, Player16 p16) {
		
		if(p1.getP1() != null) {
			p1Service.createPlayer1(p1);
		}
		if(p2.getP2() != null) {
			p2Service.createPlayer2(p2);
		}
		if(p3.getP3() != null) {
			p3Service.createPlayer3(p3);
		}
		if(p4.getP4() != null) {
			p4Service.createPlayer4(p4);
		}
		if(p5.getP5() != null) {
			p5Service.createPlayer5(p5);
		}
		if(p6.getP6() != null) {
			p6Service.createPlayer6(p6);
		}
		if(p7.getP7() != null) {
			p7Service.createPlayer7(p7);
		}
		if(p8.getP8() != null) {
			p8Service.createPlayer8(p8);
		}
		if(p9.getP9() != null) {
			p9Service.createPlayer9(p9);
		}
		if(p10.getP10() != null) {
			p10Service.createPlayer10(p10);
		}
		if(p11.getP11() != null) {
			p11Service.createPlayer11(p11);
		}
		if(p12.getP12() != null) {
			p12Service.createPlayer12(p12);
		}
		if(p13.getP13() != null) {
			p13Service.createPlayer13(p13);
		}
		if(p14.getP14() != null) {
			p14Service.createPlayer14(p14);
		}
		if(p15.getP15() != null) {
			p15Service.createPlayer15(p15);
		}
		if(p16.getP16() != null) {
			p16Service.createPlayer16(p16);
		}
		
		return "redirect:/bracket/{id}";
	}
}
	
	
	
		
		
		
		
	
			
		
		
		
		
		
		
		
	
	

	

