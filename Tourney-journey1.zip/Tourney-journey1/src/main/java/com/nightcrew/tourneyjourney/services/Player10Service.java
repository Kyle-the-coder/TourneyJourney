package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player10;
import com.nightcrew.tourneyjourney.repositories.Player10Repository;

@Service
public class Player10Service {
	
	@Autowired
	private Player10Repository p10Repo;
	
	public Player10Service(Player10Repository p10Repo) {
		this.p10Repo = p10Repo;
	}
	
	public List<Player10> allPlayer10(){
		return p10Repo.findAll();
	}
	
	public Player10 createPlayer10(Player10 p) {
		return p10Repo.save(p);
	}
	
	public List<Player10> findP10ByEventId(Long eventId){
		return p10Repo.findByEventId(eventId);
		
		
	}
	
}
