package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player16;

public interface Player16Repository extends CrudRepository<Player16, Long> {
	List<Player16> findAll();
	
	@Query(value="SELECT * FROM P16 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player16> findByEventId(Long eventId);
	
	
	
}

