package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player9;

public interface Player9Repository extends CrudRepository<Player9, Long> {
	List<Player9> findAll();
	
	@Query(value="SELECT * FROM P9 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player9> findByEventId(Long eventId);
	
	
}
