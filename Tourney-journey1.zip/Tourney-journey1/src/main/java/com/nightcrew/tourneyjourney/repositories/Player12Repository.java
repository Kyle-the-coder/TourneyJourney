package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player12;

public interface Player12Repository extends CrudRepository<Player12, Long> {
	List<Player12> findAll();
	
	@Query(value="SELECT * FROM P12 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player12> findByEventId(Long eventId);
	
	
	
}
