package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player12;
import com.nightcrew.tourneyjourney.repositories.Player12Repository;

@Service
public class Player12Service {
	@Autowired
	private Player12Repository p12Repo;
	
	public Player12Service(Player12Repository p12Repo) {
		this.p12Repo = p12Repo;
	}
	
	public List<Player12> allPlayer12(){
		return p12Repo.findAll();
	}
	
	public Player12 createPlayer12(Player12 p) {
		return p12Repo.save(p);
	}
	
	public List<Player12> findP12ByEventId(Long eventId){
		return p12Repo.findByEventId(eventId);
		
	}
	
}
