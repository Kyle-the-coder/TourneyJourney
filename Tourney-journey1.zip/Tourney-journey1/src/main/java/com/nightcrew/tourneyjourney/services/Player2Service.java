package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player2;
import com.nightcrew.tourneyjourney.repositories.Player2Repository;

@Service
public class Player2Service {
	@Autowired
	private Player2Repository p2Repo;
	
	public Player2Service(Player2Repository p2Repo) {
		this.p2Repo = p2Repo;
	}
	
	public List<Player2> allPlayer2(){
		return p2Repo.findAll();
	}
	
	public Player2 createPlayer2(Player2 p) {
		return p2Repo.save(p);
	}
	
	public List<Player2> findP1ByEventId(Long eventId){
		return p2Repo.findByEventId(eventId);
	}
	
}
