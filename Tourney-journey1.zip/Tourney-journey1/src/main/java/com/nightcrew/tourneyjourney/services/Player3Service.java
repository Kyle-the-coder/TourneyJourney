package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player3;
import com.nightcrew.tourneyjourney.repositories.Player3Repository;

@Service
public class Player3Service {
	@Autowired
	private Player3Repository p3Repo;
	
	public Player3Service(Player3Repository p3Repo) {
		this.p3Repo = p3Repo;
	}
	
	public List<Player3> allPlayer3(){
		return p3Repo.findAll();
	}
	
	public Player3 createPlayer3(Player3 p) {
		return p3Repo.save(p);
	}
	
	public List<Player3> findP3ByEventId(Long eventId){
		return p3Repo.findByEventId(eventId);
	}
}
