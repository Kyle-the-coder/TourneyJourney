package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player5;
import com.nightcrew.tourneyjourney.repositories.Player5Repository;


@Service
public class Player5Service {

	@Autowired
	private Player5Repository p5Repo;
	
	public Player5Service(Player5Repository p5Repo) {
		this.p5Repo = p5Repo;
	}
	
	public List<Player5> allPlayer5(){
		return p5Repo.findAll();
	}
	
	public Player5 createPlayer5(Player5 p) {
		return p5Repo.save(p);
	}
	
	public List<Player5> findP5ByEventId(Long eventId){
		return p5Repo.findByEventId(eventId);
	}
}
