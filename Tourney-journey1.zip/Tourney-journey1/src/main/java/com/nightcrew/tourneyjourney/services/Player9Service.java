package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player9;
import com.nightcrew.tourneyjourney.repositories.Player9Repository;

@Service
public class Player9Service {
	
	@Autowired
	private Player9Repository p9Repo;
	
	public Player9Service(Player9Repository p9Repo) {
		this.p9Repo = p9Repo;
	}
	
	public List<Player9> allPlayer9(){
		return p9Repo.findAll();
	}
	
	public Player9 createPlayer9(Player9 p) {
		return p9Repo.save(p);
	}
	
	public List<Player9> findP9ByEventId(Long eventId){
		return p9Repo.findByEventId(eventId);
		
	}
}
