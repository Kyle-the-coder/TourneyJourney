package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player3;

public interface Player3Repository extends CrudRepository<Player3, Long> {
	List<Player3> findAll();
	
	@Query(value="SELECT * FROM P3 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player3> findByEventId(Long eventId);
}
