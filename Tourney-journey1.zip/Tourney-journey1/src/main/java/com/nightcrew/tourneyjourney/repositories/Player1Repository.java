package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player1;

public interface Player1Repository extends CrudRepository<Player1, Long>{
	List<Player1> findAll();
	
	@Query(value="SELECT * FROM P1 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player1> findByEventId(Long eventId);
	
	
}
