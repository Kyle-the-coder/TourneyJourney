package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player14;

public interface Player14Repository extends CrudRepository<Player14, Long> {
	List<Player14> findAll();
	
	@Query(value="SELECT * FROM P14 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player14> findByEventId(Long eventId);
	
	
	
}

