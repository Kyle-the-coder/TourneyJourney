package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player13;
import com.nightcrew.tourneyjourney.repositories.Player13Repository;

@Service
public class Player13Service {
	@Autowired
	private Player13Repository p13Repo;
	
	public Player13Service(Player13Repository p13Repo) {
		this.p13Repo = p13Repo;
	}
	
	public List<Player13> allPlayer13(){
		return p13Repo.findAll();
	}
	
	public Player13 createPlayer13(Player13 p) {
		return p13Repo.save(p);
	}
	
	public List<Player13> findP13ByEventId(Long eventId){
		return p13Repo.findByEventId(eventId);
		
	}
	
}
