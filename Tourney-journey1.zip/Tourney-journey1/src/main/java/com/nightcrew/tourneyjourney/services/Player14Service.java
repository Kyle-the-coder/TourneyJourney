package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player14;
import com.nightcrew.tourneyjourney.repositories.Player14Repository;

@Service
public class Player14Service {

	@Autowired
	private Player14Repository p14Repo;
	
	public Player14Service(Player14Repository p14Repo) {
		this.p14Repo = p14Repo;
	}
	
	public List<Player14> allPlayer14(){
		return p14Repo.findAll();
	}
	
	public Player14 createPlayer14(Player14 p) {
		return p14Repo.save(p);
	}
	
	public List<Player14> findP14ByEventId(Long eventId){
		return p14Repo.findByEventId(eventId);
		
	}
	
}
