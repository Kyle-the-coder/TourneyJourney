package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player6;
import com.nightcrew.tourneyjourney.repositories.Player6Repository;


@Service
public class Player6Service {

	@Autowired
	private Player6Repository p6Repo;
	
	public Player6Service(Player6Repository p6Repo) {
		this.p6Repo = p6Repo;
	}
	
	public List<Player6> allPlayer6(){
		return p6Repo.findAll();
	}
	
	public Player6 createPlayer6(Player6 p) {
		return p6Repo.save(p);
	}
	
	public List<Player6> findP6ByEventId(Long eventId){
		return p6Repo.findByEventId(eventId);
	}
}
