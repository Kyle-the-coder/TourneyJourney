package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player4;

public interface Player4Repository extends CrudRepository<Player4, Long> {
	List<Player4> findAll();
	
	@Query(value="SELECT * FROM P4 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player4> findByEventId(Long eventId);
}