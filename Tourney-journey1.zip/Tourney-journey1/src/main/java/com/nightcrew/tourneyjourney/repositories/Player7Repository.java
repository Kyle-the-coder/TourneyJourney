package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player7;

public interface Player7Repository extends CrudRepository<Player7, Long> {
	List<Player7> findAll();
	
	@Query(value="SELECT * FROM P7 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player7> findByEventId(Long eventId);
	
}
