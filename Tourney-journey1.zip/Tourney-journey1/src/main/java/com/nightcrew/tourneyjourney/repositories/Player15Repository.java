package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player15;

public interface Player15Repository extends CrudRepository<Player15, Long> {
	List<Player15> findAll();
	
	@Query(value="SELECT * FROM P15 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player15> findByEventId(Long eventId);
	
	
	
	
}
