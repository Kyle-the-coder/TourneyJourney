package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player11;
import com.nightcrew.tourneyjourney.repositories.Player11Repository;

@Service
public class Player11Service {
	
	@Autowired
	private Player11Repository p11Repo;
	
	public Player11Service(Player11Repository p11Repo) {
		this.p11Repo = p11Repo;
	}
	
	public List<Player11> allPlayer11(){
		return p11Repo.findAll();
	}
	
	public Player11 createPlayer11(Player11 p) {
		return p11Repo.save(p);
	}
	
	public List<Player11> findP11ByEventId(Long eventId){
		return p11Repo.findByEventId(eventId);
		
	}
	
}
