package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player8;
import com.nightcrew.tourneyjourney.repositories.Player8Repository;

@Service
public class Player8Service {
	
	@Autowired
	private Player8Repository p8Repo;
	
	public Player8Service(Player8Repository p8Repo) {
		this.p8Repo = p8Repo;
	}
	
	public List<Player8> allPlayer8(){
		return p8Repo.findAll();
	}
	
	public Player8 createPlayer8(Player8 p) {
		return p8Repo.save(p);
	}
	
	public List<Player8> findP8ByEventId(Long eventId){
		return p8Repo.findByEventId(eventId);
		
	}
}
