package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player2;

public interface Player2Repository extends CrudRepository<Player2, Long>{
	List<Player2> findAll();
	
	@Query(value="SELECT * FROM P2 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player2> findByEventId(Long eventId);
	
}
