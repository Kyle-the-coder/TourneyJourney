package com.nightcrew.tourneyjourney.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nightcrew.tourneyjourney.models.Player5;

public interface Player5Repository extends CrudRepository<Player5, Long> {
	List<Player5> findAll();
	
	@Query(value="SELECT * FROM P5 WHERE EVENT_ID = ?1", nativeQuery=true)
	List<Player5> findByEventId(Long eventId);
}
