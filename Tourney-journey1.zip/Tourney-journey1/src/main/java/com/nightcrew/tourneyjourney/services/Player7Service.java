package com.nightcrew.tourneyjourney.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nightcrew.tourneyjourney.models.Player7;
import com.nightcrew.tourneyjourney.repositories.Player7Repository;

@Service
public class Player7Service {
	@Autowired
	private Player7Repository p7Repo;
	
	public Player7Service(Player7Repository p7Repo) {
		this.p7Repo = p7Repo;
	}
	
	public List<Player7> allPlayer7(){
		return p7Repo.findAll();
	}
	
	public Player7 createPlayer7(Player7 p) {
		return p7Repo.save(p);
	}
	
	public List<Player7> findP7ByEventId(Long eventId){
		return p7Repo.findByEventId(eventId);
		
	}
}
